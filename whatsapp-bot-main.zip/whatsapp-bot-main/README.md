## Clone this project

```bash
> git clone https://github.com/Bintangp02/sticker-bot
```

## Install the dependencies:

```bash
> npm install gify-cli -g
> npm i
```

### Usage
##### Api-Key Is Indispensable For The Bot you are using! [Api-Key](https://github.com/Bintangp02/sticker-bot/blob/master/msgHndlr.js#L62)
##### Before running this script, first edit [this section](https://github.com/Bintangp02/sticker-bot/blob/master/msgHndlr.js#L852) with your WhatsApp number, remember your WhatsApp number!  Not a bot number, then
```bash
> npm start
```

## Info Update & Fix
```
> Fix ytplay
> Fitur Clone Sudah Hadir
> Segera hadir fitur getvn
> anti delete
> Fitur hadir secara bertahab🙏
```
## Features

| Sticker Creator |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Send Photo with Caption          |
|       ✅       | Reply A Photo                    |
|       ✅       | Image Url                        |
|       ✅       | Send Video or GIF with Caption   |
|       ✅       | Sticker triggered 🆕             |


| Downloader |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |   YouTube mp3/mp4 Downloader                    |
|       ❌        |   Doujin Downloader         |
|       ✅        |   Instagram Video/Image Downloader                  |
|       ✅        |   Facebook Video Downloader                  |
|       ✅        |   Pinterest 🆕                         |
|       ✅        |   Yt Play 🆕                         |



| Other  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Get a random meme             |
|       ✅        |   Text to speech                |
|       ✅        |   Get a random waifu images     |
|       ✅        |   Get a random quotes           |
|       ✅        |   Get a random anime quotes     |
|       ✅        |   Get info gempa from BMKG      |
|       ✅        |   Weather's report's     |
|       ✅        |   Wikipedia                 |
|       ✅        |   Anime searcher    |
|       ✅        |   Get a random cat images       |
|       ✅        |   Get a random dog images       |
|       ✅        |   Info Covid Indonesia 🆕       |
|      And        |   Others...                     |


| Group Only  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Promote User                  |
|       ✅        |   Demote User                   |
|       ✅        |   Kick User                     |
|       ✅        |   Add User                      |
|       ✅        |   Mention All User              |
|       ✅        |   Get link group                |
|       ✅        |   Get Admin list                |
|       ✅        |   Get owner group               |
|       ✅        |   enable or disable nsfw command|
|       ✅        |   enable or disable welcome feature|
|       ✅        |   Create a group 🆕                |
|       ✅        |   Clone tag user 🆕                         |


| Owner Bot Only  |              Feature                |
| :------------: | :---------------------------------------------: |
|       ❌        |   leave all group                   |
|       ✅        |   clear all message                 |
|       ✅        |   Broadcast
|       ✅        |                                |
                  

## Special Thanks to..
* [`open-wa/wa-automate-nodejs`](https://github.com/open-wa/wa-automate-nodejs)
* [`YogaSakti/imageToSticker`](https://github.com/YogaSakti/imageToSticker)
* [`SomnathDas/Whatsapp-Botto-Re`](https://github.com/SomnathDas/Whatsapp-Botto-Re)
* [`Mhankbarbar/whatsapp-bot`](https://github.com/mhankbarbar)
* [`<>`](https://github.com/Bintangp02)

### Thanks a lot to!
```
Mhankbarbar untuk Sc ORI
Bintangp02 Recode
```

##### Folow My [Github](https://github.com/Bintangp02)
